﻿namespace Keycloak.Net
{
    public enum UserSyncActions
    {
        Full,
        Changed
    }
}