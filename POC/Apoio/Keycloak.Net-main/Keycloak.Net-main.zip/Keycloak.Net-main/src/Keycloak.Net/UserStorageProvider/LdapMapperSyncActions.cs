﻿namespace Keycloak.Net
{
    public enum LdapMapperSyncActions
    {
        FedToKeycloak,
        KeycloakToFed
    }
}