﻿namespace Keycloak.Net.Models.RealmsAdmin
{
    public enum Policies
    {
        Skip,
        Overwrite,
        Fail
    }
}
