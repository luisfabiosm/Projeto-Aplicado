﻿namespace Keycloak.Net.Models.Clients
{
    public enum AccessTokenCategories
    {
        Internal, 
        Access, 
        Id, 
        Admin, 
        Userinfo
    }
}
