﻿namespace Keycloak.Net.Models.Root
{
    public class MetadataClass
    {
    }
}