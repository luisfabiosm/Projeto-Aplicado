# Keycloak.Client

[![license](https://img.shields.io/github/license/nagybalint001/Keycloak.Client.svg?maxAge=2592000)](https://github.com/nagybalint001/Keycloak.Client/blob/main/LICENSE) [![NuGet](https://img.shields.io/nuget/v/Keycloak.Client.svg?maxAge=2592000)](https://www.nuget.org/packages/Keycloak.Client/) ![downloads](https://img.shields.io/nuget/dt/Keycloak.Client)

HttpClient wrapper for Keycloak API